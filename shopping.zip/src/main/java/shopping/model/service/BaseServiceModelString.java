package shopping.model.service;

public abstract class BaseServiceModelString {
    private String id;

    public BaseServiceModelString() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
